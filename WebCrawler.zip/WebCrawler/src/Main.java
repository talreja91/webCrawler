import java.io.IOException;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
 
 
public class Main {
	public static int id = 1;
	
	private HashSet<String> links;
	
	public Main() {
        links = new HashSet<String>();
    }
	
	public void getPageLinks(String URL) {
        //4. Check if you have already crawled the URLs
        //(we are intentionally not checking for duplicate content in this example)
		Document document = null;
        if (!links.contains(URL) && URL != null) {
            try {
                //4. (i) If not add it to the index
               if (links.add(URL)) {
                    System.out.println(URL);
                }

                //2. Fetch the HTML code
               if(URL != null && !(URL.equals("") || URL.equals(" ")))
               {   document = Jsoup.connect(URL).get();
                	//3. Parse the HTML to extract links to other URLs
	                Elements linksOnPage = document.select("a[href]");
	
	                //5. For each extracted URL... go back to Step 4.
	                for (Element page : linksOnPage) {
	                	if(isValidURL(page.attr("href")))
	                    getPageLinks(page.attr("abs:href"));
	                }
                }
               
            } catch (IOException e) {
                System.err.println("For '" + URL + "': " + e.getMessage());
            }
            catch(Exception e)
            {
            	System.err.println(URL + "\n" + e.getMessage());
            }
        }
    }
	
	public static void main(String[] args) throws SQLException, IOException {
		new Main().getPageLinks("http://www.mit.edu/");

	}
	public boolean isValidURL(String url)
	{
		Boolean isValid = false;
		if(url.contains("mit.edu") && !(url.contains("mailto") || url.contains(".pdf") || url.contains(".jpg") || url.contains(".png")))
			isValid= true;
	    int i = 0;
		Pattern p = Pattern.compile("mit.edu");
		Matcher m = p.matcher( url );
		while (m.find()) {
		    ++i;
		    if(i>1)
		    	{isValid = false;
		    	break;
		    	}
		}
		return isValid;
	}

}